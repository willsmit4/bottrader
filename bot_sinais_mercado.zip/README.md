# Bot de Sinais de Mercado (Telegram)

Este bot envia sinais diários de compra/venda para ações ou criptomoedas com base em análise técnica e notícias.

## 🚀 Como usar

1. Instale as dependências:
```
pip install -r requirements.txt
```

2. Preencha o arquivo `config.py` com:
   - Seu token do Telegram Bot
   - Sua chave da NewsAPI

3. Execute o bot:
```
python main.py
```

4. No Telegram, inicie uma conversa com o bot e escolha "Sinais de Ações" ou "Sinais de Criptomoedas".

## ⏱️ O bot envia sinais todos os dias às 9h.
