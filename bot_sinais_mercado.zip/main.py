import telebot
import yfinance as yf
import ccxt
import pandas as pd
import pandas_ta as ta
from apscheduler.schedulers.background import BackgroundScheduler
from newsapi import NewsApiClient
from config import TELEGRAM_TOKEN, NEWSAPI_KEY

bot = telebot.TeleBot(TELEGRAM_TOKEN)
newsapi = NewsApiClient(api_key=NEWSAPI_KEY)
users = {}

@bot.message_handler(commands=['start'])
def send_welcome(message):
    markup = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row('📈 Sinais de Ações', '💰 Sinais de Criptomoedas')
    bot.send_message(message.chat.id, "Olá! Escolha o tipo de sinal que deseja receber:", reply_markup=markup)

@bot.message_handler(func=lambda message: message.text in ['📈 Sinais de Ações', '💰 Sinais de Criptomoedas'])
def set_user_preference(message):
    choice = 'acoes' if 'Ações' in message.text else 'cripto'
    users[message.chat.id] = choice
    bot.send_message(message.chat.id, f"Você escolheu receber sinais de {choice.upper()}!")

def analisar_acao(ticker='AAPL'):
    df = yf.download(ticker, period='7d', interval='1h')
    df.ta.rsi(length=14, append=True)
    rsi = df['RSI_14'].iloc[-1]
    if rsi < 30:
        return f"[AÇÃO] {ticker}: RSI = {rsi:.2f} => COMPRAR 📈"
    elif rsi > 70:
        return f"[AÇÃO] {ticker}: RSI = {rsi:.2f} => VENDER 📉"
    return f"[AÇÃO] {ticker}: RSI = {rsi:.2f} => NEUTRO"

def analisar_cripto(symbol='BTC/USDT'):
    exchange = ccxt.binance()
    ohlcv = exchange.fetch_ohlcv(symbol, timeframe='1h', limit=100)
    df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['close'] = pd.to_numeric(df['close'])
    df.ta.rsi(length=14, append=True)
    rsi = df['RSI_14'].iloc[-1]
    if rsi < 30:
        return f"[CRIPTO] {symbol}: RSI = {rsi:.2f} => COMPRAR 📈"
    elif rsi > 70:
        return f"[CRIPTO] {symbol}: RSI = {rsi:.2f} => VENDER 📉"
    return f"[CRIPTO] {symbol}: RSI = {rsi:.2f} => NEUTRO"

def get_noticias(query='mercado'):
    noticias = newsapi.get_everything(q=query, language='pt', page_size=1)
    if noticias['articles']:
        artigo = noticias['articles'][0]
        return f"📰 {artigo['title']} - {artigo['source']['name']}
{artigo['url']}"
    return "Sem notícias relevantes hoje."

def enviar_sinais():
    for user_id, tipo in users.items():
        if tipo == 'acoes':
            sinais = analisar_acao()
            noticias = get_noticias('ações')
        else:
            sinais = analisar_cripto()
            noticias = get_noticias('criptomoedas')
        bot.send_message(user_id, f"{sinais}

{noticias}")

scheduler = BackgroundScheduler()
scheduler.add_job(enviar_sinais, 'cron', hour=9)
scheduler.start()

print("Bot rodando...")
bot.infinity_polling()
